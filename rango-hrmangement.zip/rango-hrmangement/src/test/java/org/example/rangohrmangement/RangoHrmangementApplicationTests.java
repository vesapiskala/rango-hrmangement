package org.example.rangohrmangement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RangoHrmangementApplicationTests {

    @Test
    void contextLoads() {
    }

}
