package org.example.rangohrmangement.enums;

public enum LeaveType {
    ANNUAL,
    SICK,
    UNPAID
}