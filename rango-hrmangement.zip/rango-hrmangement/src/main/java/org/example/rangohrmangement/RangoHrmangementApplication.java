package org.example.rangohrmangement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RangoHrmangementApplication {

    public static void main(String[] args) {
        SpringApplication.run(RangoHrmangementApplication.class, args);
    }

}
